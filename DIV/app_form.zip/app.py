from flask import Flask, render_template, request, redirect, url_for

app = Flask(__name__)

@app.route("/", methods=["GET"])
def index():
    ma_variable = "MA VARIABLEEE"
    return render_template("index.html", ma_variable_sur_la_page=ma_variable)

@app.route("/result", methods=["POST"])
def result():
    user_name = request.form.get("name")
    ma_variable_recuperee = request.form.get("ma_variable_a_recuperer")
    return render_template("result.html", user_name=user_name, ma_variable_recuperee_sur_ma_page_deux=ma_variable_recuperee)

if __name__ == "__main__":
    app.run(debug=True)
